# This is the encoding swallowing non asccii (neither unicode) symbols happening in MCNP models code
MCNP_ENCODING = "Cp1251"

