__title__ = 'mckit'
__author__ = 'Roman Rodionov'
__license__ = 'MIT'
__copyright__ = 'Copyright 2018-2020 Roman Rodinov'
__ver_major__ = 0
__ver_minor__ = 4
__ver_patch__ = 1
__version_info__ = (__ver_major__, __ver_minor__, __ver_patch__)
__ver_sub__ = ''
__version__ = "%d.%d.%d%s" % (__ver_major__, __ver_minor__, __ver_patch__, __ver_sub__)

